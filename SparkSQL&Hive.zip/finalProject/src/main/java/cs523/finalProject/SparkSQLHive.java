package cs523.finalProject;


import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.hive.HiveContext;

public class SparkSQLHive {
	public static void main(String[] args) {
		JavaSparkContext sc = new JavaSparkContext(new SparkConf().setAppName("electronics").setMaster("local").set("spark.sql.warehouse.dir", "/user/hive/warehouse")); 
		HiveContext hiveContext =  new HiveContext(sc);
		
		//number of view per brand
//		DataFrame resEventType = hiveContext.sql("SELECT brand, COUNT(event_type) AS viewed FROM electronics WHERE event_type='view' GROUP BY brand ORDER BY viewed DESC");
//		resEventType.show();
//		
//		//highest price
//		DataFrame highestPrice = hiveContext.sql("SELECT brand, MAX(cast(price as double)) AS highestPrice FROM electronics GROUP BY brand ORDER BY brand");
//		highestPrice.show();
		
		//total sale per brand
		DataFrame mostPurchased = hiveContext
				.sql("SELECT brand, SUM(cast(price as double)) AS totalSale FROM electronics WHERE event_type='purchase' GROUP BY brand ORDER BY totalSale DESC LIMIT 5");
		mostPurchased.show();
	}

}